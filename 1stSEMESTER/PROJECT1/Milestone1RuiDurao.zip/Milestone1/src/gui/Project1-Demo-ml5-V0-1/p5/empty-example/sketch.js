let video;
let handPose;
let hands = [];
let handConnections = [];
let webcamReady = false;
let detectionStarted = false;
let webcamMessage = "A aguardar autorização da câmara...";

function setup() {
  createCanvas(640, 480);
  console.log("ml5 version:", ml5.version);

  if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
    webcamMessage = "Abre esta página em localhost ou HTTPS para usar a câmara.";
    return;
  }

  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();
  video.elt.addEventListener("loadeddata", () => {
    webcamReady = true;
    startHandPose();
  });

  ml5.handPose()
    .then((model) => {
      handPose = model;
      handConnections = handPose.getConnections();
      startHandPose();
    })
    .catch((error) => {
      console.error("Could not load the Hand Pose model:", error);
    });
}

function startHandPose() {
  if (webcamReady && handPose && !detectionStarted) {
    handPose.detectStart(video, gotHands);
    detectionStarted = true;
  }
}

function gotHands(results) {
  hands = results;
}

function draw() {
  background(220);

  if (webcamReady) {
    image(video, 0, 0, width, height);
    drawHandLandmarks();
  } else {
    fill(30);
    textAlign(CENTER, CENTER);
    text(webcamMessage, width / 2, height / 2, width - 40);
  }
}

function drawHandLandmarks() {
  for (const hand of hands) {
    stroke(0, 255, 120);
    strokeWeight(3);

    for (const [startIndex, endIndex] of handConnections) {
      const start = hand.keypoints[startIndex];
      const end = hand.keypoints[endIndex];

      line(start.x, start.y, end.x, end.y);
    }

    noStroke();
    fill(255, 80, 80);

    for (const keypoint of hand.keypoints) {
      circle(keypoint.x, keypoint.y, 10);
    }
  }
}